<!DOCTYPE html>
<html>
	 
<head>
	<?php include 'head.php';?>
	<title></title>
</head>
<body>

<?php include 'menu.php';?>



<table>

<td>
<a href="addcust.php">
<input type="button"  class="btn btn-primary btn-lg" style="background-color: #7f2908;" name="btnsave" value="New Customer?"></a>
</td>

<td>
<a href="bill.php">
<input type="button" class="btn btn-primary btn-lg" style="background-color: #77BBCC;" name="btnsave" value="Existing Customer?"></a>
</td>
</table>


<table class="table" cellpadding="2" border="3" style="width:100%">
        <tr>
          <td>Customer ID</td>
          <td>Name</td>
          <td>Contact</td>
          <td>Car Company</td>
          <td>Car Number</td>
          <td>Category</td>
          <td>Car Type</td>
          <td>Car Colour</td>
        </tr>

      <?php
      $q=pg_query("select * from tblcust;");
      while ($r=pg_fetch_array($q)) {
      	?>
      		
       
        <tr>
        	
          <td><?php	echo $r['custid'];?></std>
          <td><?php	echo $r['custname'];?></td>
          <td><?php	echo $r['custcon'];?></td>
          <td><?php	echo $r['carcom'];?></td>
          <td><?php echo $r['carno'];?></td>
          <td><?php echo $r['carcat'];?></td>
          <td><?php echo $r['cartype'];?></td>
          <td><?php echo $r['carclr'];?></td>
          
        </tr>			
        <?php	
      }
      ?>
        <br>

</table>
			<!--  to this -->





<?php include 'footer.php';?>
</body>
</html>