<!DOCTYPE html>
<html>
<head>
	<?php include 'head.php';?>
	<title></title>
</head>
<body>
<?php include 'menu.php';?>
<center>
<input type="button" onClick="print()" value="Please Visit Again">
</center>
<form method="post">
<table class="table">
	<tr>
		
					<td>
						Choose Customer
					</td>
					<td>
				
					<select name="cmbpackage" class="form-control">
						<?php
					$q=pg_query("select * from tblcust");
					while ($r=pg_fetch_array($q)) {
						?>
							<option value="<?php echo $r['custid'];?>"><?php echo $r['custname'];?></option>
						<?php
						}	
					?>
					</select>

					
				
			</td>
		</tr>
		<Tr>
			<Td>
				<input type="submit" name="btnshow" value="Show">
			</Td>
		</Tr>
		</table>
	</form>
<?php
if(isset($_POST['btnshow'])){
	extract($_POST);
	header("location:printbill.php?id=$cmbpackage");
}
if($_GET['id']){
	?>

	<table class="table">
		<Tr>
			<Td>
				Customer Name
			</Td>
			<Td>
				Package Name
			</Td>
			<Td>
				Charges
			</Td>
			<Td>
				Description
			</Td>
			<Td>
				..
			</Td>
		</Tr>
		<?php
	
	$q=pg_query("select * from tblbill,tblcust,tblanulpkg where tblbill.cid=tblcust.custid and tblanulpkg.pkgid=tblcust.pkgid and tblbill.cid=".$_GET['id']);
	while($r=pg_fetch_array($q)){
		?>
		<Tr>
			<td>
				<?php echo $r['custname'];?>
			</td>
			<Td>
				<?php echo $r['pkgname'];?>
			</Td>
			<Td><?php
		echo $r['ac']; $total+=$r['ac'];
		?>
	</Td>
	<td>
		<?php echo $r['pdesc'];?>
	</td>
	

	<td> 
		<a href="cancel.php?bid=<?php echo $r['bid'];?>"> Cancel</a>

	</Tr>
	
	<?php
	}
?>


<Tr>
	<Td>
		Total
	</Td>
	<Td>
		Rs<?php echo $total;?>/-
	</Td>
</Tr>

</table>
<?php
}
?>


<?php include 'footer.php';?>
</body>
</html>