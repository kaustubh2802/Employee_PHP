<!DOCTYPE html>
<html>
   
<head>
  <?php include 'head.php';?>
  <title></title>

<!------------- demo css-------------->





</head>
<body>
 
<?php include 'menu.php';?>



<link rel="stylesheet" href="css/styledemo.css">
<div class="bc">


  
<center>
 
<a href="addcust.php" >
<div class="ok">
<input type="button" class="btn23" name="btnsave" value="New Customer?"></a>
</div>
</center>



  <table class="table" cellpadding="2" border="3" style="width:100%">
  <tr>
    <td>Name</td>
    <td>Contact</td>
    <td>Vehicle No.</td>
    <td>Vehicle Type</td>
    <td>Vehicle company</td>
  </tr>

<?php

$a=pg_query("select * from tblcust;"); 
while ($r=pg_fetch_array($a)) {  
  $id = $row['custid']; ?>
    
 
  <tr>
    
    <td><?php echo $r['custname'];?></std>
    <td><?php echo $r['custcon'];?></td>
    <td><?php echo $r['carno'];?></td>
    <td><?php echo $r['cartype'];?></td>
    <td><?php echo $r['carcom'];?></td>

  </tr>     
  <?php 
}
?>
  <br>

</table>
      <!--  to this -->






<!-- this div is bg class of css-->     </div>


<footer>

<?php include 'footer.php';?>

</footer>

</body>
</html>

<!--
if(isset($_POST['update']))
{

$query=pg_query("update tblcust set CategoryName='$catname',CategoryCode='$catcode' where id='$cid'");
} -->



                
