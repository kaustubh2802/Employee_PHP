<nav class="navbar navbar-expand-lg navbar-dark bg-primary"> 


 
        <a class="nav-link active" aria-current="page" href="index.php">Home</a>
        <?php
        
        if($_SESSION['adid']==null){
          ?>
        <!--<a class="nav-link" href="register.php">New Admin ?</a> -->
        <a class="nav-link" href="login.php">MANAGER</a>
        <?php
        }
        else{

        ?>
       
         <a class="nav-link" href="customer.php">Customer</a>
        <a class="nav-link" href="employee.php">Team</a>
        <a class="nav-link" href="modification.php">Modification</a>
        <a class="nav-link" href="service.php">Services</a>
        <a class="nav-link" href="bill.php">Accounting</a>
        <a class="nav-link" href="viewvendor.php">Vendors</a>
        <a class="nav-link" href="package.php">Package</a>


         

        
       <div class="ok">
        <a class="nav-link " href="logout.php">
          <button type="button"  class="btn-logout" style="float">Logout</button>
        </a>
      </div>


      


        <!-- <button type="button" class="btn btn-lg btn-primary" data-toggle="popover" title="Popover title" data-content="And here's some amazing content. It's very engaging. Right?">Click</button>   -->


      

        <?php
      }
      ?>
       
       
      
</nav>

