<nav class="navbar navbar-expand-lg navbar-primary bg-secondary">
  <div class="container-fluid">



    <a class="navbar-brand" href="#">SK Garage</a>
    

        <table>

            <th><td>
    
            <a class="nav-link active" aria-current="page" href="index.php">Home</a></td>
            <?php
            
            if($_SESSION['adid']==null){
              ?>
            <td><a class="nav-link" href="register.php">New Admin</a></td>
            <td><a class="nav-link" href="login.php">Admin-Login</a></td>
          </th></table>

            <?php
            }
            else{

            ?>

           <table>

            <th><td>
             <a class="nav-link" href="addcust.php">Add Customer</a></td>

             <td>
            
            <td><a class="nav-link" href="employee.php">Team</a></td>
            <td><a class="nav-link" href="modification.php">Modification</a></td>
            <td><a class="nav-link" href="service.php">Services</a></td>
            <td><a class="nav-link" href="bill.php">Accounting</a></td>
            <td><a class="nav-link" href="vendor.php">Vendors</a></td>
            <td><a class="nav-link" href="package.php">Package</a></td>
            
            <td><a align="right" class="nav-link" href="logout.php"><button type="button" class="btn btn-danger">Logout</button></a></td>

          </th></table>

        <?php
      }
      ?>
       
     
    </div>
  
</nav>
