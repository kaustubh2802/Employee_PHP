



<?php require 'head.php';
pg_query("delete from tblbill where bid=".$_GET['bid']);
header("location:printbill.php");
?>