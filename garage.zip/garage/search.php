<!DOCTYPE html>
<html>
<head>
	<?php include 'head.php';?>
	<title></title>
</head>
<body>
<?php include 'menu.php';?>

<p>hello<br>pradeep</p>
<div class="row">

	<br>
<br>
<br>
<form method="post">
	<table>
		<tr>
			<td>
				Search By Vehicle Number
			</td>
			


			<td>
				<input type="text" name="carno" class="form-control">
					<?php
$q=pg_query("select * from tblcust");
while ($r=pg_fetch_array($q)) {




	?>

<option value="<?php echo $r['custid'];?>"><?php echo $r['carno'];?></option>

<?php
}
?>

</select>
</td>
</tr>
<tr>
	<td>
		<input type="submit" name="btnsearch" value="Search">
</td>
</tr>

</table>
</form>

<?php
	if(isset($_POST["btnsearch"])){
			extract($_POST);
			$q=pg_query("Select * from tblcust where custid='$carno'");
		}
		else
		{			$q=$q=pg_query("Select * from tblcust");		
	}
	while ($r=pg_fetch_array($q)) {
	?>


 <div class="col-md-3">
	<table>
		<h5><th>customer Details</th></h5>
		<p>
			<table>
		<Tr>
			<td>	customer name	</td>
			<td>	<?php	echo $r['custname'];?>	</td>
		</Tr>
		<Tr>
			<td>		Contact	</td>
			<td>  		<?php	echo $r['custcon'];?> 	</td>
		</Tr>
		<Tr>
			<td> 	Vehicle Number		</td>
			<td>	<?php	echo $r['carno'];?>	</td>
		</Tr>
		
		
		



	</table></p>
	

</table>
	</div>
<?php	
}
?>
</div>

<?php include 'footer.php';?>
</body>
</html>








