<!-- Footer -->

<body>
  <div>

<!-- <footer class="text-center text-lg-start bg-info text-muted"> -->
<footer style="color:yellow; background-color:black ;">
<?php 
echo "<body style='background-color:'>";
?>


  <!-- Section: Social media -->
  
  <section class="footer">
    

     <marquee> <h4>Our Garage is productive, wonderful, and has the mission of having your head out in a vehicle that will keep you, your travelers, and different drivers out and about out of damage’s way. 
     </h4>
          </marquee>
        


 
    
  <!--  <a class="text-reset fw-bold" href="#">Developed By S.S.PINGLE & K.P.BHOLE</a> -->



  


<br><br>






</section>



  <!-- Copyright -->
</footer>
<!-- Footer -->
<script type="text/javascript" src="js/mdb.min.js"></script>
    <!-- Custom scripts -->
    <script type="text/javascript"></script>

</div>
<div>
    <marquee bgcolor = "Green" direction = "right"> 
    <p style="color:black;"> Guide By Prof.S.P.Chitte </p>
  </marquee>
  </div>


  </body>
