<!DOCTYPE html>
<html>
<head>
	<?php include 'head.php'?>
	<title></title>
</head>
<body>
	<?php if(isset($_POST["btnsave"])){
			extract($_POST);
			pg_query("insert into tblcust(custname,custcon,carno,cartype,carcat,carclr,carcom,pkgid) values ('$txtcustname','$txtcustcon','$txtcarno','$txtcartype','$txtcaracat','$txtcarclr','$txtcarcom','$cmbpackage')");
			
		}
	?>

	<?php include 'menu.php'?>
	<div class="row">
		<div class="col-md-6">
		<form method="post">
		<table class="table" cellpadding="2" border="3" style="width:100%;">
			<tr>
				<td>
					Customer Name
				</td>
				<td>
					<input type="text" name="txtcustname" class="form-control">
				</td>
			</tr>
			<tr>
				<td>
					 Contact
				</td>
				<td>
					<input type="text" name="txtcustcon" class="form-control">
				</td>
			</tr>
			
			<tr>
				<td>
					Car No
				</td>
				<td>
					<input type="text" name="txtcarno"  class="form-control" float="MH15BT8055">
				</td>
			</tr>
			<tr>
				<td>
					Car Type
				</td>
				<td>
					<button type="button" class="btn btn-danger dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    					Action
  						</button>

  						
					<select name="txtcartype" class="form-control">
					<option>Hatchback</option>
					<option>Sedan</option>
					<option>Suv</option>
					<option>Crossover</option>
						
					</select>



					
				</td>
			</tr>
			<tr>
				<td>
					Car Colour
				</td>
				<td>
					<input type="text" name="txtcarclr"  class="form-control">
				</td>
			</tr>

			<tr>
				<td>
					Car Category
				</td>
				<td>
					<select name="txtcarcat" class="form-control">
					<option>Petrol</option>
					<option>Diesel</option>
					<option>Gas</option>
					<option>Electric</option>
						
					</select>
				</td>
			</tr>
			<tr>
				<td>
					Car Company
				</td>
				<td>
					<input type="text" name="txtcarcom"  class="form-control">
				</td>
			</tr>
				<tr>
					<td>
						Choose Package
					</td>
					<td>
				
					<select name="cmbpackage" class="form-control">
						<?php
					$q=pg_query("select * from tblanulpkg");
					while ($r=pg_fetch_array($q)) {
						?>
							<option value="<?php echo $r['pkgid'];?>"><?php echo $r['pkgname'];?></option>
						<?php
						}	
					?>
					</select>

					
				
			</td>
		</tr>

			<tr>
				<Td colspan=2 align="center">
					<a href="customer.php" >*
					<input type="submit" class="btn btn-success"  name="btnsave" value="Register Customer"> *</a>
				</Td>
				
			</tr>
	</table>
</form>
</div>
</div>



<?php include 'footer.php'?>
</body>
</html>

