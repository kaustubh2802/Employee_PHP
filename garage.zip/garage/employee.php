<!DOCTYPE html>
<html>
	 
<head>
	<?php include 'head.php';?>
	<title>Employee</title>








</head>
<body>

<?php include 'menu.php';?>


<link rel="stylesheet" href="css/styledemo.css">
<div class="bgclr">


<center>
<a href="addemp.php">
<input type="button" class="btn btn-outline-warning" name="btnsave" value="New Employee ?"></a>
</center>




	<table class="table" cellpadding="2" border="3" style="width:100%">
  <tr>
    <td>Name</td>
    <td>Contact</td>
    <td>Joining Date</td>
    <td>Salary</td>
  </tr>

<?php
$q=pg_query("select * from tblemp;");
while ($r=pg_fetch_array($q)) {
	?>
		
 
  <tr>
  	
    <td><?php	echo $r['ename'];?></std>
    <td><?php	echo $r['econ'];?></td>
    <td><?php	echo $r['ejoindt'];?></td>
    <td><?php	echo $r['esal'];?></td>
    
  </tr>			
  <?php	
}
?>
  <br>

</table>


</div>


			<!--  to this -->





  <?php include 'footer.php';?>
</body>
</html>