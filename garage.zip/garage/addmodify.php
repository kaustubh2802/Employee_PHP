<!DOCTYPE html>
<html>
<head>
	<?php include 'head.php'?>
	<title></title>

<style>
	#grad2 {
  height: 400px;
  width: 100%;
  background-color: red; 

  background-image: linear-gradient(to right, red, orange, yellow, green, blue, indigo, violet);
  
}
</style>
   <!--background-image: radial-gradient(circle, red,white,blue);-->

</head>
<body>
	

	<?php if(isset($_POST["btnsave"])){
			extract($_POST);
			pg_query("insert into tblmodfy(mname,mcat,mdesc,mprice) values ('$tmname','$tmcat','$tmdesc','$tmprice')");
		}
	?>

	<?php include 'menu.php'?>
	<div id="grad2">
	<div class="row">
		<div class="col-md-6">


			




		<form method="post">
		<table class="table" cellpadding="2" border="3" style="width:100%">
			<tr>
				<td>
					Modification Name
				</td>
				<td>
					<input type="text" name="tmname" class="form-control" autofocus>
				</td>
			</tr>
			
			<tr>
				<td>
					Category
				</td>
				<td>
					<input type="text" name="tmcat"  class="form-control">
					<p>Internel/Externel</p>
					
				</td>
			</tr>
			<tr>
			<tr>
				<td>
					Description
				</td>
				<td>
					<input type="text" name="tmdesc"  class="form-control">
				</td>
			</tr>
			<tr>
				<td>
					Price
				</td>
				<td>
					<input type="text" name="tmprice"  class="form-control">
				</td>
			</tr>
		
			<tr>
				<Td colspan=2 align="center">
					<input type="submit" class="btn btn-success" onclick="modification.php" name="btnsave" value="Add modification ">
				</Td>
			</tr>
	</table>
</form>
</div>
</div>
</div>



<?php include 'footer.php'?>
</body>
</html>

