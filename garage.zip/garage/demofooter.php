<!-- Footer -->
<footer class="text-center text-lg-start bg-info text-muted">
<?php 
echo "<body style='background-color:'>";
?>
<footer>

  <!-- Section: Social media -->
  
  <section class="eicon-chevron-left">

      
      
          <h2>SK GARAGE</h2>
          <p>
            The SK is productive, wonderful, and has the mission of having your head out in a vehicle that will keep you, your travelers, and different drivers out and about out of damage’s way. 
          </p>
     
<BR><BR><BR><BR>
        
        
            <a class="text-reset fw-bold" href="#">Developed By S.S.PINGLE & K.P.BHOLE
                </a>
        

</table>

  





</section>
</footer>
<script type="text/javascript" src="js/mdb.min.js"></script>
   
    <script type="text/javascript"></script>