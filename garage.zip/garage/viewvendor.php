<!DOCTYPE html>
<html>
<head>
	<?php include 'head.php';?>
	<title></title>
</head>
<body>
<?php include 'menu.php';?>


<a href="vendor.php">

<center>
	<input type="button" class="btn btn-outline-warning"name="btnsave" value="New Vendor ?"></a>

</center>


<div class="row width:100px" >
<?php
$q=pg_query("select * from tblvendors");
while ($r=pg_fetch_array($q)) {
	?>
	

<div class="col-md-3">
		<div class="card">
  <div class="card-body">
    
    <p class="card-text">


    
    <table class="table" cellpadding="2" border="3" style="width:30%">
				<Tr>
					<td> Name </td>
					<td>	<?php echo $r['vname'];?> </td>
				</Tr>

				<Tr>
					<td> Description 	</td>
					<td> <?php echo $r['vdesc'];?></td>
				</Tr>


				<Tr>
					<td>Contact</td>
					<td><?php echo $r['vcont'];?> </td>
				</Tr>


				<Tr>
					<td>Quantity</td>
					<td><?php echo $r['vqty'];?> </td>
				</Tr>



					

	</table>
	</div>
</div>
	
</div>
	<?php	} ?>

</div>





<?php include 'footer.php';?>
</body>
</html>